FreePixelFood
art: benmhenry@gmail.com
code: davidahenry@gmail.com

Description:
Includes sixty-four 16 by 16 detailed pixel art food sprites.<br><br>
Cookie, Brownie, Stein, Moonshine, Whiskey, Tart, Sushi, Sashimi, Saki, Boar, Marmalade, Jam, Apple, AppleWorm, Turnip, Potato, Eggs, Honeycomb, Pineapple, Bacon, Beer, Steak, Wine, Fish, Cheese, Chicken, Bread, Eggplant, PepperRed, PepperGreen, Grubs, Grub, Tomato, Strawberry, Peach, Lemon, PiePumpkin, PieLemon, PieApple, Pickle, Pretzel, Pepperoni, FishFillet, Honey, Jerky, PotatoRed, MelonHoneydew, MelonCantaloupe, MelonWater, Waffles, ChickenLeg, Cherry, Ribs, Sardines, DragonFruit, Sausages, Avocado, FishSteak, Bug, Olive, PickledEggs, Roll, Onion

Documentation:
Files:
FreePixelFood/Sprite/Food.png : all in one, sprite sheet
FreePixelFood/Sprite/Food/Cookie.png (etc) : split, individual, duplicate, alternative, sprites
FreePixelFood/Food.unity : example scene
FreePixelFood/ReadMe.txt : this
